from airflow import DAG
from airflow.operators.python import PythonOperator
from datetime import datetime, timedelta
import requests
from bs4 import BeautifulSoup
import psycopg2

URL = "https://vnexpress.net/chu-de/tri-tue-nhan-tao-ai-11638"

default_args = {
    'owner': 'huynh',
    'retries': 3,
    'retry_delay': timedelta(minutes=5),
}

def crawl_ai_articles():
    response = requests.get(URL)
    soup = BeautifulSoup(response.content, 'html.parser')

    articles = []
    for item in soup.select('.box-category-item'):
        title = item.h3.text.strip() if item.h3 else None
        url = item.a['href'] if item.a else None
        time_tag = item.select_one('.time')
        published_time = time_tag.text.strip() if time_tag else None
        if title and url:
            articles.append((title, url, published_time))
    return articles

def save_to_postgres(**context):
    articles = context['ti'].xcom_pull(task_ids='crawl_articles')

    conn = psycopg2.connect(
        host='postgres',
        database='airflow',
        user='airflow',
        password='airflow'
    )
    cur = conn.cursor()

    cur.execute("""
        CREATE TABLE IF NOT EXISTS ai_articles (
            id SERIAL PRIMARY KEY,
            title TEXT,
            url TEXT,
            published_time TEXT,
            crawled_at TIMESTAMP DEFAULT NOW()
        );
    """)

    for title, url, published_time in articles:
        cur.execute("""
            INSERT INTO ai_articles (title, url, published_time)
            VALUES (%s, %s, %s);
        """, (title, url, published_time))

    conn.commit()
    cur.close()
    conn.close()

with DAG(
    dag_id='cat_pipeline',
    default_args=default_args,
    description='Crawl AI articles from VnExpress and store in PostgreSQL',
    schedule_interval='0 7 * * *',  # 07:00 AM mỗi ngày
    start_date=datetime(2024, 1, 1),
    catchup=False,
    tags=['vnexpress', 'ai', 'cat_pipeline']
) as dag:

    t1 = PythonOperator(
        task_id='crawl_articles',
        python_callable=crawl_ai_articles
    )

    t2 = PythonOperator(
        task_id='save_to_postgres',
        python_callable=save_to_postgres,
        provide_context=True
    )

    t1 >> t2
